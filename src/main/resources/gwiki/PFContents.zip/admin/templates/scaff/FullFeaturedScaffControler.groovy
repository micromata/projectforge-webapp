import de.micromata.genome.gwiki.page.impl.actionbean.*;

class WikiControlActionBean extends ActionBeanBase {
	String input;

	public Object onInit() {
		return null;
	}

	public Object onOk() {
		return null;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String inp) {
		input = inp;
	}
}
