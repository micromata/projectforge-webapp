<div class="grid_16">
	<div class="indented round_all clearfix send_left">
		<ul class="breadcrumb clearfix">
			<li><a href="#"><div class="ui-icon ui-icon-home"></div></a></li>
			<li><a href="#">Level 1</a></li>
			<li><a href="#">Level 2</a></li>
			<li><span>Current</span></li>
		</ul>
	</div>
	<div class="send_right round_all indented">
		<div class="toggle_all round_all">
			<a href="#" class="hide_all">hide all</a>
			<a href="#" class="show_all">show all</a>
		</div>
	</div>
</div>