		<div id="loading_overlay">
			<div class="loading_message round_bottom">
				<img src="images/loading.gif" alt="loading" />
			</div>
		</div>
		
		<?php include 'includes/template_options.php'?>		
	</body>
</html>