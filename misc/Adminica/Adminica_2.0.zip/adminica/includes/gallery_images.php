<ul class="clearfix">
	
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image01.jpg">
		<img src="images/gallery/blue/image01_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 1</span>
		<span class="size">71234kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image2.jpg">
		<img src="images/gallery/blue/image02_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 2</span>
		<span class="size">7235kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image3.jpg"
		><img src="images/gallery/blue/image03_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 3</span>
		<span class="size">1456kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image04.jpg">
		<img src="images/gallery/blue/image04_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 4</span>
		<span class="size">45671kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image05.jpg">
		<img src="images/gallery/blue/image05_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 5</span>
		<span class="size">15678kb</span></a></li>
	
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image06.jpg">
		<img src="images/gallery/blue/image06_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 6</span>
		<span class="size">16678kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image07.jpg">
		<img src="images/gallery/blue/image07_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 7</span>
		<span class="size">17678kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image08.jpg">
		<img src="images/gallery/blue/image08_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 8</span>
		<span class="size">19678kb</span></a></li>
		
	<li class="blue">
		<a rel="collection" href="images/gallery/blue/image09.jpg">
		<img src="images/gallery/blue/image09_thumb.jpg" height="84" width="148"/>
		<span class="name">Blue 9</span>
		<span class="size">110678kb</span></a></li>	

<!-- BW Images -->		
				
	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image01.jpg">
		<img src="images/gallery/grey/image01_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 1</span>
		<span class="size">234kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image02.jpg">
		<img src="images/gallery/grey/image02_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 2</span>
		<span class="size">2345kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image03.jpg"
		><img src="images/gallery/grey/image03_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 3</span>
		<span class="size">23456kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image04.jpg">
		<img src="images/gallery/grey/image04_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 4</span>
		<span class="size">456677kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image05.jpg">
		<img src="images/gallery/grey/image05_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 5</span>
		<span class="size">5678kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image06.jpg">
		<img src="images/gallery/grey/image06_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 6</span>
		<span class="size">678kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image07.jpg">
		<img src="images/gallery/grey/image07_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 7</span>
		<span class="size">7678kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image08.jpg">
		<img src="images/gallery/grey/image08_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 8</span>
		<span class="size">1978kb</span></a></li>

	<li class="bw">
		<a rel="collection" href="images/gallery/grey/image09.jpg">
		<img src="images/gallery/grey/image09_thumb.jpg" height="84" width="148"/>
		<span class="name">Grey 9</span>
		<span class="size">1108kb</span></a></li>

<!-- Sepia Images -->
	
	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image01.jpg">
		<img src="images/gallery/sepia/image01_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 1</span>
		<span class="size">71234kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image02.jpg">
		<img src="images/gallery/sepia/image02_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 2</span>
		<span class="size">2345kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image03.jpg"
		><img src="images/gallery/sepia/image03_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 3</span>
		<span class="size">3456kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image04.jpg">
		<img src="images/gallery/sepia/image04_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 4</span>
		<span class="size">4567kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image05.jpg">
		<img src="images/gallery/sepia/image05_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 5</span>
		<span class="size">15678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image06.jpg">
		<img src="images/gallery/sepia/image06_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 6</span>
		<span class="size">16678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image07.jpg">
		<img src="images/gallery/sepia/image07_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 7</span>
		<span class="size">17678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image08.jpg">
		<img src="images/gallery/sepia/image08_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 8</span>
		<span class="size">19678kb</span></a></li>

	<li class="sepia">
		<a rel="collection" href="images/gallery/sepia/image09.jpg">
		<img src="images/gallery/sepia/image09_thumb.jpg" height="84" width="148"/>
		<span class="name">Sepia 9</span>
		<span class="size">110678kb</span></a></li>

		
</ul>