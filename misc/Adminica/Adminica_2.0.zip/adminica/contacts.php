<?php include 'includes/document_head.php'?>	
		<div id="wrapper">	
			<?php include 'includes/topbar.php'?>		
			<?php include 'includes/sidebar.php'?>

			<div id="main_container" class="main_container container_16 clearfix">
				<?php $keyphrase = '7'; include 'includes/navigation.php'?>
				<div class="box grid_6">
					<h2 class="box_head">Form Elements</h2>
					<div id="slider_list">
						<div class="slider-content">
							<ul>
								<li id="a"><a name="a" class="title">A</a>
									<ul>
										<li><a href="#">Adam</a></li>
										<li><a href="#">Alex</a></li>
										<li><a href="#">Ali</a></li>
										<li><a href="#">Apple</a></li>
										<li><a href="#">Arthur</a></li>
										<li><a href="#">Ashley</a></li>
									</ul>
								</li>
								<li id="b"><a name="b" class="title">B</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="c"><a name="c" class="title">c</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="d"><a name="d" class="title">d</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="e"><a name="e" class="title">E</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="f"><a name="f" class="title">f</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="g"><a name="g" class="title">g</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="h"><a name="h" class="title">h</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="i"><a name="i" class="title">i</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="j"><a name="j" class="title">j</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="k"><a name="k" class="title">k</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="l"><a name="l" class="title">l</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="m"><a name="m" class="title">m</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="n"><a name="n" class="title">n</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="o"><a name="o" class="title">o</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="p"><a name="p" class="title">p</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="q"><a name="q" class="title">q</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="r"><a name="r" class="title">r</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="s"><a name="s" class="title">s</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="t"><a name="t" class="title">t</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="u"><a name="u" class="title">u</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="v"><a name="v" class="title">v</a>
									<ul>
										<li><a href="#">Barry</a></li>
										<li><a href="#">Becky</a></li>
										<li><a href="#">Biff</a></li>
										<li><a href="#">Billy</a></li>
										<li><a href="#">Bozarking</a></li>
										<li><a href="#">Bryan</a></li>
									</ul>
								</li>
								<li id="w"><a name="w" class="title">w</a>
									<ul>
										<li><a href="#">Calista</a></li>
										<li><a href="#">Cathy</a></li>
										<li><a href="#">Chris</a></li>
										<li><a href="#">Cinderella</a></li>
										<li><a href="#">Corky</a></li>
										<li><a href="#">Cypher</a></li>
									</ul>
								</li>
								<li id="x"><a name="x" class="title">x</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="y"><a name="y" class="title">y</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
								<li id="z"><a name="z" class="title">z</a>
									<ul>
										<li><a href="#">damien</a></li>
										<li><a href="#">danny</a></li>
										<li><a href="#">denver</a></li>
										<li><a href="#">devon</a></li>
										<li><a href="#">doug</a></li>
										<li><a href="#">dustin</a></li>
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="flat_area grid_10">
					<h2>Contact List</h2>
					<p>This<strong> apple style contact list</strong> is just as useful on the big screen as on an iPhone. Of course it can list anything not just contacts...</p>
					<p>Try it out and you'll see how quickly you can locate the desired entry. Amazing!</p>
				</div>
			</div>
		</div>
		
<script type="text/javascript" src="scripts/slidernav/slidernav.js"></script>

<script type="text/javascript"> 		
	
	//This configures the iPhone style Contacts display)	  
 		$('#slider_list').sliderNav({height:'500'});

</script>

<?php include 'includes/closing_items.php'?>