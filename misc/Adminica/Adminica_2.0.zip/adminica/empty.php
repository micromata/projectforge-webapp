<?php include 'includes/document_head.php'?>
		<div id="wrapper">	
			<?php include 'includes/topbar.php'?>		
			<?php include 'includes/sidebar.php'?>
			<div id="main_container" class="main_container container_16 clearfix">
				<?php include 'includes/navigation.php'?>
				<div class="flat_area grid_16">
					<h2>Empty Page <small>(A good starting point)</small></h2>
					<p>At vero eos et accusamus et iusto odio <a href="#">dignissimos ducimus qui blanditiis</a> praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et <strong>expedita distinctio</strong>. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.</p>
				</div>
				<div class="box grid_16">
					<h2 class="box_head">Empty Box</h2>
					<a href="#" class="grabber">&nbsp;</a>
					<a href="#" class="toggle">&nbsp;</a>
					<div class="block">
						<div class="section">
							<p>Content goes here</p>
						</div>					
					</div>
				</div>
			</div>
		</div>
<?php include 'includes/closing_items.php'?>